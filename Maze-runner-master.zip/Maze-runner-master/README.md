# Maze-runner
A pacman styled 2-D game written in python.

* A pacman styled 2-D game which generates random mazes upon every iteration. Objective is to help our main character find a way
out of the maze.
* Uses recursive backtracking for maze generation. Also allows the option to solve the random generated maze using graph algorithms.
* Highly efficient Graphical User Interface written in Python pygame library.
